
import React from 'react';
import { Waveform } from '../constants';

const PathBIntegratedSlide: React.FC = () => {
  return (
    <div className="relative w-full h-full flex flex-col p-10 text-white overflow-hidden bg-[#040505] rounded-[40px] border border-emerald-500/20 shadow-2xl">
      <Waveform color="#10B981" />
      
      {/* Header Section */}
      <div className="w-full flex justify-between items-start mb-6 z-10">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-3">
             <span className="px-3 py-1 bg-emerald-500/20 border border-emerald-500/40 rounded-full text-[10px] font-black text-emerald-400 tracking-[0.2em] uppercase">The Integrated Build</span>
             <div className="h-px w-12 bg-emerald-500/20" />
          </div>
          <h2 className="text-4xl font-black tracking-tighter uppercase leading-tight">
            PATH B: WHAT WE <span className="text-emerald-500 italic">BUILD</span>
          </h2>
          <p className="text-xs font-bold text-white/30 uppercase tracking-widest italic">A Hybrid Strategy for Maximum Enterprise Valuation</p>
        </div>
        <div className="flex gap-4">
            <div className="bg-emerald-500/10 border border-emerald-500/30 px-5 py-2.5 rounded-2xl flex items-center gap-3 shadow-lg">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-[0_0_15px_#10B981]" />
                <span className="text-xs font-black uppercase tracking-widest text-white">Custom IP Strategy ⭐</span>
            </div>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6 z-10 flex-1 overflow-hidden">
        
        {/* LEFT COLUMN: CUSTOM BUILT (GREEN) */}
        <div className="col-span-7 flex flex-col gap-4 overflow-y-auto pr-2 custom-scrollbar pb-10">
          <div className="bg-emerald-500/10 border-2 border-emerald-500/30 p-6 rounded-[32px] relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full -mr-16 -mt-16 blur-3xl" />
            
            <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-emerald-500 text-black rounded-xl shadow-lg">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                </div>
                <h3 className="text-lg font-black uppercase tracking-widest text-white">CUSTOM-BUILT COMPONENTS</h3>
            </div>

            <div className="grid grid-cols-2 gap-x-8 gap-y-6">
                <FeatureCard 
                    title="Native Drops System" 
                    items={["True Database Objects", "Lifecycle State Machine", "S3 Media Management", "Superfan Early Access"]}
                    color="emerald"
                />
                <FeatureCard 
                    title="Behavioral Intel Engine" 
                    items={["Real-time Engagement Scoring", "Activity Tracking (Views/Plays)", "Predictive Superfan Likelihood", "Churn Risk Analysis"]}
                    color="emerald"
                />
                <FeatureCard 
                    title="Advanced Analytics" 
                    items={["Cross-Artist Admin Dash", "Cohort & Retention Logic", "Conversion Funnels", "Real-time Refreshing Data"]}
                    color="emerald"
                />
                <FeatureCard 
                    title="Automated Revenue" 
                    items={["Auto 80/20 Revenue Splits", "Artist Payout Dashboards", "Tax/1099-K Automation", "Subscription Management"]}
                    color="emerald"
                />
                <FeatureCard 
                    title="Artist Hub & Fan Portal" 
                    items={["Premium Music UI/UX", "Custom Branded Portals", "PWA / Mobile Native Feel", "Direct Fan Messaging"]}
                    color="emerald"
                />
                <FeatureCard 
                    title="Cross-Pollination" 
                    items={["Recommendation Algorithms", "Shared Fan Identity", "Discovery Path Analytics", "Unified Platform Login"]}
                    color="emerald"
                />
            </div>

            <div className="mt-8 p-4 bg-black/40 border border-emerald-500/20 rounded-2xl">
                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400 block mb-2 underline underline-offset-4">Security & Admin</span>
                <div className="grid grid-cols-2 gap-x-4">
                    <Bullet point="JWT Auth & Granular RBAC" />
                    <Bullet point="GDPR & PCI-DSS Compliance" />
                    <Bullet point="Platform Control Center" />
                    <Bullet point="Security Audit Logging" />
                </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: GHL POWERED (BLUE) */}
        <div className="col-span-5 flex flex-col gap-4">
          <div className="bg-blue-600/5 border-2 border-blue-500/30 p-6 rounded-[32px] flex-1">
            <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-blue-600 text-white rounded-xl shadow-lg">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                </div>
                <h3 className="text-lg font-black uppercase tracking-widest text-white">GHL-POWERED (API)</h3>
            </div>

            <div className="space-y-4">
                <GHLSection title="CRM & Fan Database" items={["Bi-directional Sync", "Timeline History", "Tag-based Segmentation"]} />
                <GHLSection title="Email & SMS Automation" items={["Branded Nurture Flows", "Transactional Comms", "Broadcast Campaigns"]} />
                <GHLSection title="Lead Capture & Forms" items={["WP-Integrated Landers", "Waitlists & Contests", "Artist Onboarding Forms"]} />
                <GHLSection title="Calendar & Booking" items={["Virtual Concert Sched", "Meet & Greet Reminders", "Timezone Sync Engine"]} />
            </div>

            {/* INTEGRATION BRIDGE */}
            <div className="mt-8 p-5 bg-gradient-to-r from-emerald-500/20 to-blue-500/20 border border-white/10 rounded-3xl relative">
                <div className="flex justify-between items-center">
                    <div className="flex flex-col">
                        <span className="text-[10px] font-black uppercase tracking-widest text-white mb-1">Integration Layer</span>
                        <span className="text-xl font-black text-white italic tracking-tighter">Bi-Directional API</span>
                    </div>
                    <svg className="w-10 h-10 text-white/20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>
                </div>
            </div>
          </div>

          {/* WHY IT'S BRILLIANT BOX */}
          <div className="bg-white text-black p-6 rounded-[32px] shadow-2xl relative overflow-hidden group hover:scale-[1.02] transition-transform">
             <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/20 rounded-full -mr-16 -mt-16 blur-2xl" />
             <h3 className="text-xs font-black uppercase tracking-[0.3em] mb-3 opacity-40 italic">The Verdict</h3>
             <h4 className="text-2xl font-black uppercase tracking-tighter leading-none mb-3">Why This Integrated Approach is Brilliant</h4>
             <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                <Bullet dark point="Saves $25K+ in dev" />
                <Bullet dark point="Launch ready day 1" />
                <Bullet dark point="Own the IP Asset" />
                <Bullet dark point="Scales to 10k artists" />
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const FeatureCard = ({ title, items, color }: { title: string; items: string[]; color: string }) => (
  <div className="group/card">
    <h4 className={`text-[11px] font-black uppercase tracking-widest mb-3 border-l-2 border-${color}-500 pl-3 leading-none`}>{title}</h4>
    <ul className="space-y-1.5">
      {items.map((item, i) => (
        <li key={i} className="flex items-start gap-2">
           <span className={`text-${color}-500 text-[10px] mt-0.5`}>•</span>
           <span className="text-[11px] font-bold text-white/50 group-hover/card:text-white transition-colors leading-tight uppercase tracking-tighter">{item}</span>
        </li>
      ))}
    </ul>
  </div>
);

const GHLSection = ({ title, items }: { title: string; items: string[] }) => (
  <div className="bg-black/40 border border-white/5 p-4 rounded-2xl group hover:border-blue-500/40 transition-colors">
    <h4 className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-2">{title}</h4>
    <div className="flex flex-wrap gap-x-4 gap-y-1">
        {items.map((item, i) => (
            <span key={i} className="text-[10px] font-bold text-white/40 group-hover:text-white/80 transition-colors tracking-tight uppercase">• {item}</span>
        ))}
    </div>
  </div>
);

const Bullet = ({ point, dark = false }: { point: string; dark?: boolean }) => (
  <div className="flex items-center gap-2">
    <div className={`w-1 h-1 rounded-full ${dark ? 'bg-black/20' : 'bg-emerald-500/50'}`} />
    <span className={`text-[10px] font-bold uppercase tracking-tight ${dark ? 'text-black/60' : 'text-white/40'}`}>{point}</span>
  </div>
);

export default PathBIntegratedSlide;
