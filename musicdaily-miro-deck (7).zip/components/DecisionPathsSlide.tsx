
import React from 'react';
import { Waveform } from '../constants';

const DecisionPathsSlide: React.FC = () => {
  return (
    <div className="relative w-full h-full flex flex-col p-12 text-white overflow-hidden bg-black/40 backdrop-blur-sm rounded-3xl border border-white/5 shadow-2xl">
      <Waveform />
      
      {/* Header */}
      <div className="w-full flex justify-between items-center mb-8 z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#FFB800] rounded flex items-center justify-center">
            <span className="text-black font-bold text-xs">05</span>
          </div>
          <h2 className="text-sm font-bold uppercase tracking-[0.3em] text-white/50">Technical Decision - Two Paths</h2>
        </div>
        <div className="h-px flex-1 mx-8 bg-white/10" />
        <span className="text-xs font-mono text-[#FFB800]">ROADMAP_2026</span>
      </div>

      <div className="flex-1 flex flex-col items-center z-10">
        {/* Fork in the Road Visual */}
        <div className="relative w-full flex flex-col items-center mb-12">
          <div className="bg-white/10 px-6 py-2 rounded-full border border-white/20 text-xs font-black uppercase tracking-widest mb-4">
            Your Platform
          </div>
          
          <svg className="w-64 h-24 mb-4" viewBox="0 0 200 80" fill="none">
            <path d="M100 0V30" stroke="white" strokeWidth="2" strokeDasharray="4 4" opacity="0.5" />
            <path d="M100 30C100 50 40 50 20 80" stroke="#3B82F6" strokeWidth="3" strokeLinecap="round" />
            <path d="M100 30C100 50 160 50 180 80" stroke="#10B981" strokeWidth="3" strokeLinecap="round" />
            <circle cx="100" cy="30" r="4" fill="white" />
          </svg>
        </div>

        <div className="grid grid-cols-2 gap-12 w-full max-w-5xl">
          {/* PATH A: GHL */}
          <div className="relative group">
            <div className="absolute -inset-1 bg-blue-500/20 rounded-3xl blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
            <div className="relative bg-[#1a1a1a]/80 border border-blue-500/30 rounded-2xl p-8 h-full">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <span className="text-blue-400 text-[10px] font-black uppercase tracking-[0.2em] mb-1 block">Path A</span>
                  <h3 className="text-3xl font-black text-white">GHL <span className="text-blue-400/50">(V1)</span></h3>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-white/40 uppercase block">Launch</span>
                  <span className="text-xl font-black text-blue-400">4-6 WEEKS</span>
                </div>
              </div>

              <div className="space-y-6">
                <DetailRow icon={<ClockIcon color="#3B82F6" />} label="Speed" value="FASTER" color="text-blue-400" />
                <DetailRow icon={<DollarIcon color="#3B82F6" />} label="Initial Cost" value="LOWER" color="text-blue-400" />
                <DetailRow icon={<AlertIcon color="#F59E0B" />} label="Constraint" value="LIMITATIONS" color="text-orange-400" />
                <DetailRow icon={<RefreshIcon color="#3B82F6" />} label="Outlook" value="MIGRATION NEEDED" color="text-white/60" />
              </div>
            </div>
          </div>

          {/* PATH B: CUSTOM */}
          <div className="relative group">
            <div className="absolute -inset-1 bg-green-500/20 rounded-3xl blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
            <div className="relative bg-[#1a1a1a]/80 border border-green-500/30 rounded-2xl p-8 h-full">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <span className="text-green-400 text-[10px] font-black uppercase tracking-[0.2em] mb-1 block">Path B</span>
                  <h3 className="text-3xl font-black text-white">CUSTOM <span className="text-green-400/50">PLATFORM</span></h3>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-white/40 uppercase block">Launch</span>
                  <span className="text-xl font-black text-green-400">10-14 WEEKS</span>
                </div>
              </div>

              <div className="space-y-6">
                <DetailRow icon={<BuildIcon color="#10B981" />} label="Effort" value="LONGER BUILD" color="text-green-400" />
                <DetailRow icon={<DollarIcon color="#10B981" />} label="Initial Cost" value="HIGHER" color="text-green-400" />
                <DetailRow icon={<CheckIcon color="#10B981" />} label="Control" value="FULL OWNERSHIP" color="text-green-400" />
                <DetailRow icon={<RocketIcon color="#10B981" />} label="Outlook" value="SCALES INFINITELY" color="text-white/60" />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-auto pt-8 italic text-white/30 text-sm tracking-wide">
          Let's evaluate BOTH options in detail...
        </div>
      </div>
    </div>
  );
};

const DetailRow = ({ icon, label, value, color }: { icon: React.ReactNode, label: string, value: string, color: string }) => (
  <div className="flex items-center gap-4">
    <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center">
      {icon}
    </div>
    <div className="flex-1">
      <span className="text-[10px] font-bold uppercase tracking-widest text-white/30 block mb-0.5">{label}</span>
      <span className={`text-sm font-black uppercase tracking-tight ${color}`}>{value}</span>
    </div>
  </div>
);

const ClockIcon = ({ color }: { color: string }) => <svg className="w-4 h-4" style={{ color }} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const DollarIcon = ({ color }: { color: string }) => <svg className="w-4 h-4" style={{ color }} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const AlertIcon = ({ color }: { color: string }) => <svg className="w-4 h-4" style={{ color }} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>;
const RefreshIcon = ({ color }: { color: string }) => <svg className="w-4 h-4" style={{ color }} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>;
const BuildIcon = ({ color }: { color: string }) => <svg className="w-4 h-4" style={{ color }} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>;
const CheckIcon = ({ color }: { color: string }) => <svg className="w-4 h-4" style={{ color }} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" /></svg>;
const RocketIcon = ({ color }: { color: string }) => <svg className="w-4 h-4" style={{ color }} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>;

export default DecisionPathsSlide;
