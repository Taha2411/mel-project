
import React from 'react';
import { COLORS, Waveform } from '../constants';

const ArchitectureSlide: React.FC = () => {
  return (
    <div className="relative w-full h-full flex flex-col p-12 text-white overflow-hidden bg-black/40 backdrop-blur-sm rounded-3xl border border-white/5 shadow-2xl">
      <Waveform />
      
      {/* Header */}
      <div className="w-full flex justify-between items-center mb-8 z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#FFB800] rounded flex items-center justify-center">
            <span className="text-black font-bold text-xs">03</span>
          </div>
          <h2 className="text-sm font-bold uppercase tracking-[0.3em] text-white/50">Platform Architecture Overview</h2>
        </div>
        <div className="h-px flex-1 mx-8 bg-white/10" />
        <span className="text-xs font-mono text-[#FFB800]">TECH_FLOW_2026</span>
      </div>

      <div className="flex flex-col items-center justify-between flex-1 z-10 gap-4">
        
        {/* TIER 1: EDITORIAL FRONT */}
        <div className="w-full max-w-4xl bg-white/5 border border-white/10 rounded-2xl p-6 group hover:bg-white/[0.07] transition-all relative">
          <div className="absolute -left-4 top-1/2 -translate-y-1/2 w-1 h-12 bg-white/20 rounded-full" />
          <div className="flex justify-between items-start mb-4">
            <div>
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 mb-1 block">Tier 01</span>
              <h3 className="text-xl font-black tracking-tight">EDITORIAL FRONT <span className="text-white/40 font-light">(MusicDaily.com)</span></h3>
            </div>
            <div className="bg-white/10 px-3 py-1 rounded text-[10px] font-bold uppercase tracking-widest">Public Access</div>
          </div>
          <div className="grid grid-cols-4 gap-4">
            <Feature icon={<GlobeIcon />} label="Public Content" />
            <Feature icon={<NewsIcon />} label="Editorial News" />
            <Feature icon={<KeyIcon />} label="Login Portal" />
            <Feature icon={<ChartIcon />} label="Discovery Engine" />
          </div>
        </div>

        {/* Transition Arrow 1 */}
        <div className="flex flex-col items-center -my-2 opacity-50">
           <svg className="w-6 h-6 text-[#FFB800]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7-7-7m14-8l-7 7-7-7" />
           </svg>
           <span className="text-[9px] font-bold text-white/30 uppercase mt-1">User Auth</span>
        </div>

        {/* TIER 2: ARTIST HUB */}
        <div className="w-full max-w-4xl bg-white/10 border border-white/20 rounded-2xl p-6 group hover:bg-white/[0.12] transition-all relative">
          <div className="absolute -left-4 top-1/2 -translate-y-1/2 w-1 h-12 bg-white/40 rounded-full" />
          <div className="flex justify-between items-start mb-4">
            <div>
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/60 mb-1 block">Tier 02</span>
              <h3 className="text-xl font-black tracking-tight uppercase">Artist Hub <span className="text-white/40 font-light">(Regular Fans)</span></h3>
            </div>
            <div className="bg-white/20 px-3 py-1 rounded text-[10px] font-bold uppercase tracking-widest text-white/80">Authenticated</div>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <Feature icon={<MusicIcon />} label="Profile & Bio" />
            <Feature icon={<BoxIcon />} label="Public Drops" />
            <Feature icon={<UsersIcon />} label="Community Feed" />
            <Feature icon={<LockIcon />} label="Locked Preview" />
            <Feature icon={<HeartIconSmall />} label="5 Favorite Artists" />
            <div className="flex items-center gap-3 bg-[#FFB800]/10 border border-[#FFB800]/30 p-2.5 rounded-xl">
               <div className="text-[#FFB800]"><StarIcon /></div>
               <span className="text-xs font-bold uppercase tracking-tight text-[#FFB800]">Upgrade to Superfan</span>
            </div>
          </div>
        </div>

        {/* Transition Arrow 2 */}
        <div className="flex flex-col items-center -my-2">
           <svg className="w-6 h-6 text-[#FFB800]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7-7-7m14-8l-7 7-7-7" />
           </svg>
           <span className="text-[9px] font-bold text-[#FFB800] uppercase mt-1">Subscription</span>
        </div>

        {/* TIER 3: SUPERFAN STATE */}
        <div className="w-full max-w-4xl bg-[#FFB800] text-black border border-[#FFB800] rounded-2xl p-6 group shadow-[0_0_40px_rgba(255,184,0,0.15)] relative">
          <div className="absolute -left-4 top-1/2 -translate-y-1/2 w-1 h-12 bg-black rounded-full" />
          <div className="flex justify-between items-start mb-4">
            <div>
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-black/40 mb-1 block">Tier 03</span>
              <h3 className="text-xl font-black tracking-tight uppercase">Superfan State <span className="text-black/40 font-light">(Premium)</span></h3>
            </div>
            <div className="bg-black/10 px-3 py-1 rounded text-[10px] font-bold uppercase tracking-widest">Full Access</div>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <Feature dark icon={<ClockIcon />} label="Early Drop Access" />
            <Feature dark icon={<ShoppingBagIcon />} label="Exclusive Merch" />
            <Feature dark icon={<VideoIcon />} label="BTS Content" />
            <Feature dark icon={<MessageIcon />} label="Direct Messaging" />
            <Feature dark icon={<MicIcon />} label="Live Streams" />
            <Feature dark icon={<TrophyIcon />} label="Premium Badge" />
          </div>
        </div>
      </div>
    </div>
  );
};

const Feature = ({ icon, label, dark = false }: { icon: React.ReactNode, label: string, dark?: boolean }) => (
  <div className={`flex items-center gap-3 p-2.5 rounded-xl transition-all ${dark ? 'bg-black/5' : 'bg-white/5'}`}>
    <div className={dark ? 'text-black' : 'text-[#FFB800]'}>{icon}</div>
    <span className={`text-xs font-bold uppercase tracking-tight ${dark ? 'text-black/80' : 'text-white/80'}`}>{label}</span>
  </div>
);

// Icons
const GlobeIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" /></svg>;
const NewsIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10l4 4v10a2 2 0 01-2 2zM7 8h5m-5 4h5m-5 4h10" /></svg>;
const KeyIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 11-7.743-5.743L11 5l-1 1V5l-1 1V5l-1 1V5L6 7l-2 2v2l2 2v3l1 1v1l1 1h2l1-1v-2a1 1 0 001-1v-1a1 1 0 001-1v-1a1 1 0 001-1h3.182L17 14.909M17 14a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;
const ChartIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>;
const MusicIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2z" /></svg>;
const BoxIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>;
const UsersIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>;
const LockIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>;
const HeartIconSmall = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>;
const StarIcon = () => <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.382-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" /></svg>;
const ClockIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const ShoppingBagIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" /></svg>;
const VideoIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>;
const MessageIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>;
const MicIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>;
const TrophyIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" /></svg>;

export default ArchitectureSlide;
