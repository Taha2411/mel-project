
import React from 'react';
import { Waveform } from '../constants';

const InvestmentRequiredSlide: React.FC = () => {
  const setupInclusions = [
    "Custom Frontend",
    "Backend API + DB",
    "GoHighLevel Sync",
    "Stripe 80/20 Splits",
    "Drop Manager UI",
    "Behavioral Scoring",
    "Analytics Dash",
    "Email/SMS Automation",
    "30 Artist Configs",
    "Training & Docs",
    "2w Launch Support"
  ];

  const monthlyCosts = [
    { label: "GoHighLevel License", price: "$497/mo" },
    { label: "Cloud Hosting", price: "$200-$300/mo" },
    { label: "Stripe Fees", price: "2.9% + $0.30" },
    { label: "Other Services", price: "$50-$100/mo" }
  ];

  const timeline = [
    { weeks: "W1-2", title: "Architecture", desc: "DB design & GHL logic" },
    { weeks: "W3-5", title: "Backend", desc: "API & Payment Sync" },
    { weeks: "W6-8", title: "Frontend", desc: "Hubs & Dashboards" },
    { weeks: "W9", title: "Testing", desc: "QA & Hardening" },
    { weeks: "W10", title: "LAUNCH 🚀", desc: "Live with 15 artists" }
  ];

  return (
    <div className="relative w-full h-full flex flex-col p-10 text-white overflow-hidden bg-[#0A0B0C] rounded-[40px] border border-white/10 shadow-2xl">
      <Waveform color="#FFB800" />
      
      {/* Header - Compacted */}
      <div className="w-full flex justify-between items-start mb-6 z-10">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-3">
             <span className="px-3 py-0.5 bg-[#FFB800]/20 border border-[#FFB800]/40 rounded-full text-[9px] font-black text-[#FFB800] tracking-[0.2em] uppercase">Project Financials</span>
             <div className="h-px w-12 bg-[#FFB800]/20" />
          </div>
          <h2 className="text-4xl font-black tracking-tighter uppercase leading-tight text-white">
            INVESTMENT <span className="text-[#FFB800] italic">REQUIRED</span>
          </h2>
          <p className="text-[10px] font-bold text-white/30 uppercase tracking-[0.2em] italic">Scalable Infrastructure & Professional Implementation</p>
        </div>
        <div className="bg-white/5 border border-white/10 px-5 py-2 rounded-2xl flex flex-col items-end">
            <span className="text-[9px] font-black text-white/40 uppercase tracking-widest">Total Delivery</span>
            <span className="text-lg font-black text-[#FFB800] italic leading-none">8 - 10 WEEKS</span>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6 z-10 flex-1 overflow-hidden">
        
        {/* Left: Setup & Costs */}
        <div className="col-span-8 flex flex-col gap-5 overflow-y-auto pr-2 custom-scrollbar pb-6">
          
          {/* Main Setup Card - Optimized for space */}
          <div className="bg-white/[0.03] border-2 border-white/10 rounded-[28px] p-6 shadow-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-40 h-40 bg-[#FFB800]/5 rounded-full -mr-20 -mt-20 blur-3xl group-hover:bg-[#FFB800]/10 transition-colors" />
            
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h3 className="text-[11px] font-black uppercase tracking-[0.3em] text-[#FFB800] mb-1">💰 SETUP COST (ONE-TIME)</h3>
                    <span className="text-4xl font-black tracking-tighter">$10,000 — $11,000</span>
                </div>
                <div className="px-3 py-1.5 bg-[#FFB800] rounded-lg text-black font-black text-[9px] uppercase tracking-widest shadow-lg">Professional Build</div>
            </div>

            <div className="grid grid-cols-3 gap-x-4 gap-y-2">
                <span className="col-span-3 text-[9px] font-black uppercase tracking-widest text-white/30 mb-1 border-b border-white/5 pb-1">Full Platform Inclusion</span>
                {setupInclusions.map((item, i) => (
                    <div key={i} className="flex items-center gap-2 py-0.5 group/item">
                        <div className="w-1 h-1 rounded-full bg-[#FFB800] shadow-[0_0_5px_#FFB800] flex-shrink-0" />
                        <span className="text-[10px] font-bold text-white/60 group-hover/item:text-white transition-colors uppercase tracking-tight truncate">{item}</span>
                    </div>
                ))}
            </div>
          </div>

          {/* Monthly Costs & Support - Side by Side */}
          <div className="grid grid-cols-2 gap-5">
            <div className="bg-white/[0.02] border border-white/10 rounded-[24px] p-5">
                <h3 className="text-[10px] font-black uppercase tracking-widest text-white/40 mb-3 italic">💵 MONTHLY COSTS (ONGOING)</h3>
                <div className="space-y-2">
                    {monthlyCosts.map((cost, i) => (
                        <div key={i} className="flex justify-between items-center border-b border-white/5 pb-1.5">
                            <span className="text-[10px] font-bold text-white/40 uppercase tracking-tighter">{cost.label}</span>
                            <span className="text-[10px] font-black text-white">{cost.price}</span>
                        </div>
                    ))}
                    <div className="flex justify-between items-center pt-2">
                        <span className="text-[11px] font-black text-[#FFB800] uppercase tracking-widest">Est. Monthly</span>
                        <span className="text-lg font-black text-[#FFB800] tracking-tighter">~$750 - $900</span>
                    </div>
                </div>
            </div>

            <div className="bg-[#FFB800]/5 border border-[#FFB800]/20 rounded-[24px] p-5 flex flex-col justify-center">
                <h3 className="text-[10px] font-black uppercase tracking-widest text-[#FFB800] mb-2">Optional Support Retainer</h3>
                <div className="flex items-baseline gap-1.5 mb-2">
                    <span className="text-xl font-black text-white">$1,500</span>
                    <span className="text-[9px] font-bold text-white/40 uppercase">/Mo</span>
                </div>
                <p className="text-[9px] font-bold text-white/50 leading-relaxed uppercase italic">
                    Includes priority fixes, feature updates, and technical artist support. 
                    <span className="text-white ml-1 font-black underline underline-offset-2">Or pay-as-you-go.</span>
                </p>
            </div>
          </div>
        </div>

        {/* Right: Timeline - Vertical Visual */}
        <div className="col-span-4 flex flex-col">
          <div className="bg-white/[0.02] border border-white/10 rounded-[28px] p-6 flex flex-col h-full relative overflow-hidden shadow-inner">
            <div className="absolute top-0 right-0 w-full h-16 bg-gradient-to-b from-[#FFB800]/5 to-transparent pointer-events-none" />
            
            <h3 className="text-[11px] font-black uppercase tracking-[0.2em] text-white/60 mb-6 border-b border-white/10 pb-3">IMPLEMENTATION TIMELINE</h3>
            
            <div className="space-y-5 flex-1 relative">
                <div className="absolute left-5 top-2 bottom-2 w-px bg-white/10" />
                
                {timeline.map((phase, i) => (
                    <div key={i} className="flex items-start gap-4 relative group/step">
                        <div className="w-10 h-10 rounded-lg bg-black border border-white/10 flex items-center justify-center text-[9px] font-black text-white/40 group-hover/step:border-[#FFB800] group-hover/step:text-[#FFB800] transition-all shadow-lg z-10">
                            {phase.weeks}
                        </div>
                        <div className="flex flex-col">
                            <h4 className="text-[11px] font-black uppercase tracking-tight text-white group-hover/step:text-[#FFB800] transition-colors">{phase.title}</h4>
                            <p className="text-[9px] font-bold text-white/20 leading-tight uppercase italic truncate max-w-[140px]">{phase.desc}</p>
                        </div>
                    </div>
                ))}
            </div>

            <div className="mt-6 pt-6 border-t border-white/10">
                <div className="bg-[#FFB800] text-black rounded-xl p-3 flex items-center justify-between shadow-2xl group hover:scale-[1.02] transition-transform cursor-default">
                    <div className="flex flex-col">
                        <span className="text-[8px] font-black uppercase opacity-60">Status</span>
                        <span className="text-[11px] font-black uppercase tracking-tighter leading-tight italic">Ready to Blueprint</span>
                    </div>
                    <svg className="w-6 h-6 opacity-40 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvestmentRequiredSlide;
