
import React from 'react';
import { COLORS, Waveform } from '../constants';

const VisionSlide: React.FC = () => {
  return (
    <div className="relative w-full h-full flex flex-col p-16 text-white overflow-hidden bg-black/40 backdrop-blur-sm rounded-3xl border border-white/5 shadow-2xl">
      <Waveform />
      
      {/* Header */}
      <div className="w-full flex justify-between items-center mb-12 z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#FFB800] rounded flex items-center justify-center">
            <span className="text-black font-bold text-xs">02</span>
          </div>
          <h2 className="text-sm font-bold uppercase tracking-[0.3em] text-white/50">Project Vision & Scope</h2>
        </div>
        <div className="h-px flex-1 mx-8 bg-white/10" />
        <span className="text-xs font-mono text-[#FFB800]">STRATEGY_DECK_2026</span>
      </div>

      <div className="grid grid-cols-12 gap-12 z-10 flex-1">
        {/* Left Column: Vision */}
        <div className="col-span-5 flex flex-col justify-center">
          <div className="mb-4 inline-block">
            <span className="text-[#FFB800] text-xs font-black uppercase tracking-widest border border-[#FFB800]/30 px-3 py-1 rounded">The Vision</span>
          </div>
          <h3 className="text-4xl font-extrabold mb-8 leading-tight">
            Consolidating the <br/>
            <span className="text-[#FFB800]">Fragmented</span> Artist Stack.
          </h3>
          
          <div className="space-y-4">
            <div className="bg-white/5 p-6 rounded-2xl border border-white/10 relative overflow-hidden group hover:border-[#FFB800]/30 transition-colors">
              <div className="flex flex-col gap-4">
                <div className="flex items-center gap-3 text-white/40 grayscale group-hover:grayscale-0 transition-all">
                  <span className="text-xl">❌</span>
                  <p className="text-sm font-medium tracking-wide">Bandzoogle, Lay-lo, Loopfan</p>
                </div>
                <div className="h-px bg-white/10 w-full" />
                <div className="flex items-center gap-3">
                  <span className="text-xl">✅</span>
                  <p className="text-xl font-bold text-white tracking-tight">ONE INTEGRATED PLATFORM</p>
                </div>
              </div>
            </div>
            
            <p className="text-white/50 text-sm leading-relaxed pl-4 border-l-2 border-[#FFB800]/30">
              Removing technical friction so emerging artists can focus 100% on their craft while we handle the business infrastructure.
            </p>
          </div>
        </div>

        {/* Right Column: Objectives */}
        <div className="col-span-7 grid grid-cols-2 gap-4">
          <ObjectiveCard 
            icon={<TargetIcon />}
            title="Discovery"
            desc="Helping Tier-6 artists build sustainable fanbases from zero."
          />
          <ObjectiveCard 
            icon={<DollarIcon />}
            title="Monetization"
            desc="Superfan subscription models for immediate recurring revenue."
          />
          <ObjectiveCard 
            icon={<HeartIcon />}
            title="Engagement"
            desc="Deep, data-rich relationships that go beyond social media algorithms."
          />
          <ObjectiveCard 
            icon={<ShieldIcon />}
            title="Ownership"
            desc="Artists maintain 100% control of their data, fans, and identity."
          />
          
          {/* Scale Objective (Full Width) */}
          <div className="col-span-2 bg-[#FFB800] p-6 rounded-2xl flex items-center justify-between text-black">
            <div className="flex flex-col">
              <span className="text-[10px] font-black uppercase tracking-[0.2em] mb-1">Scale Strategy</span>
              <h4 className="text-2xl font-black">PHASED EXPANSION</h4>
            </div>
            <div className="flex items-center gap-6">
              <div className="flex flex-col items-center">
                <span className="text-3xl font-black">30</span>
                <span className="text-[10px] font-bold uppercase">Artists</span>
              </div>
              <svg className="w-12 h-6" viewBox="0 0 48 24" fill="none">
                <path d="M2 12H46M46 12L36 4M46 12L36 20" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <div className="flex flex-col items-center">
                <span className="text-3xl font-black">1,000+</span>
                <span className="text-[10px] font-bold uppercase">Global Reach</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ObjectiveCard = ({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) => (
  <div className="bg-white/5 p-6 rounded-2xl border border-white/10 hover:bg-white/[0.08] transition-all group">
    <div className="text-[#FFB800] mb-4 group-hover:scale-110 transition-transform origin-left">
      {icon}
    </div>
    <h4 className="text-lg font-bold mb-2 uppercase tracking-wide">{title}</h4>
    <p className="text-xs text-white/40 leading-relaxed">{desc}</p>
  </div>
);

const TargetIcon = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
);
const DollarIcon = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
);
const HeartIcon = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" /></svg>
);
const ShieldIcon = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
);

export default VisionSlide;
