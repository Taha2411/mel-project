
import React from 'react';
import { Waveform } from '../constants';

const GHLOverviewSlide: React.FC = () => {
  const features = [
    "Landing pages & funnels",
    "Email & SMS automation",
    "CRM (contact management)",
    "Communities (forums, chat)",
    "Membership sites",
    "Course hosting",
    "Payment integration (Stripe)",
    "Calendars & appointments",
    "Workflows & automations",
    "Sub-accounts (white-label)"
  ];

  return (
    <div className="relative w-full h-full flex flex-col p-12 text-white overflow-hidden bg-black/40 backdrop-blur-sm rounded-3xl border border-white/5 shadow-2xl">
      <Waveform />
      
      {/* Header */}
      <div className="w-full flex justify-between items-center mb-8 z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#3B82F6] rounded flex items-center justify-center">
            <span className="text-white font-bold text-xs">06</span>
          </div>
          <h2 className="text-sm font-bold uppercase tracking-[0.3em] text-white/50">Path A: GoHighLevel (V1 Launch)</h2>
        </div>
        <div className="h-px flex-1 mx-8 bg-white/10" />
        <span className="text-xs font-mono text-blue-400">IMPLEMENTATION_A</span>
      </div>

      <div className="grid grid-cols-12 gap-8 z-10 flex-1 overflow-hidden">
        {/* Left Column: Platform Overview & Features */}
        <div className="col-span-7 flex flex-col gap-6">
          <div className="bg-blue-500/5 border border-blue-500/20 rounded-2xl p-6">
            <h3 className="text-2xl font-black mb-4 flex items-center gap-3">
              <span className="text-blue-400">WHAT IS</span> GOHIGHLEVEL?
            </h3>
            <p className="text-sm text-white/60 leading-relaxed mb-6">
              GoHighLevel is an all-in-one marketing & CRM platform designed 
              for agencies and businesses. It allows us to white-label a powerful 
              engine for artist management.
            </p>
            
            <div className="grid grid-cols-2 gap-x-4 gap-y-3">
              {features.map((feature, i) => (
                <div key={i} className="flex items-start gap-2 text-[11px] font-bold text-white/80 uppercase tracking-tight">
                  <span className="text-blue-400 mt-0.5">
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                  </span>
                  {feature}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h4 className="text-xs font-black uppercase tracking-widest text-blue-400 mb-4">🎯 Why it's tempting</h4>
            <div className="grid grid-cols-3 gap-4 text-center">
              <TemptingItem label="All-in-One" sub="No juggling tools" />
              <TemptingItem label="4-6 Weeks" sub="Rapid Launch" />
              <TemptingItem label="Proven" sub="Agency standard" />
            </div>
          </div>
        </div>

        {/* Right Column: Cost & Timeline */}
        <div className="col-span-5 flex flex-col gap-6">
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 h-full flex flex-col">
            <h3 className="text-xs font-black uppercase tracking-widest text-white/40 mb-6">Cost Structure</h3>
            
            <div className="space-y-8 flex-1">
              <div>
                <span className="text-[10px] font-bold uppercase text-blue-400/60 block mb-1">Monthly Recurring</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black">$297-497</span>
                  <span className="text-xs text-white/30 font-bold">/MO</span>
                </div>
                <p className="text-[10px] text-white/40 mt-1 uppercase">Unlimited sub-accounts for artists</p>
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase text-blue-400/60 block mb-1">Setup Investment</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-black">$4K - $6K</span>
                </div>
                <p className="text-[10px] text-white/40 mt-1 uppercase">One-time configuration build</p>
              </div>

              <div className="pt-6 border-t border-white/10">
                <div className="flex justify-between items-center bg-blue-500/10 p-4 rounded-xl border border-blue-500/20">
                  <div>
                    <span className="text-[10px] font-black uppercase text-blue-400">Launch Timeline</span>
                    <p className="text-lg font-black uppercase">4-6 Weeks</p>
                  </div>
                  <div className="text-blue-400 opacity-50">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const TemptingItem = ({ label, sub }: { label: string, sub: string }) => (
  <div className="flex flex-col items-center">
    <span className="text-sm font-black uppercase text-white mb-0.5">{label}</span>
    <span className="text-[9px] font-bold uppercase text-white/30 tracking-widest">{sub}</span>
  </div>
);

export default GHLOverviewSlide;
