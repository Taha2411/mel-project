
import React from 'react';
import { Waveform } from '../constants';

const GHLVerdictSlide: React.FC = () => {
  const scorecard = [
    { feature: "Fan Registration", status: "READY", quality: "Excellent", color: "text-green-500" },
    { feature: "Artist Hub (Communities)", status: "READY", quality: "Good", color: "text-green-500" },
    { feature: "Subscriptions & Payments", status: "READY", quality: "Good", color: "text-green-500" },
    { feature: "Email/SMS Automation", status: "READY", quality: "Excellent", color: "text-green-500" },
    { feature: "Custom Branding", status: "READY", quality: "Excellent", color: "text-green-500" },
    { feature: "Drop Management", status: "LIMIT", quality: "Workaround", color: "text-orange-500" },
    { feature: "Behavioral Scoring", status: "LIMIT", quality: "Approximate", color: "text-orange-500" },
    { feature: "Analytics & Insights", status: "LIMIT", quality: "Basic Only", color: "text-orange-500" },
    { feature: "Revenue Automation", status: "FAIL", quality: "Manual", color: "text-red-500" },
    { feature: "Cross-Artist Intel", status: "FAIL", quality: "Not Possible", color: "text-red-500" },
    { feature: "Platform Dashboards", status: "FAIL", quality: "Not Possible", color: "text-red-500" },
    { feature: "Scale to 1,000+", status: "FAIL", quality: "Will Break", color: "text-red-500" },
  ];

  return (
    <div className="relative w-full h-full flex flex-col p-12 text-white overflow-hidden bg-[#0D0D0D] rounded-3xl border border-white/5 shadow-2xl">
      <Waveform />
      
      {/* Header */}
      <div className="w-full flex justify-between items-center mb-10 z-10">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-[#FFB800] rounded-xl flex items-center justify-center shadow-[0_0_25px_rgba(255,184,0,0.3)]">
            <span className="text-black font-black text-sm">09</span>
          </div>
          <div>
            <h2 className="text-2xl font-black tracking-tight uppercase">PATH A: <span className="text-[#FFB800]">GHL FEASIBILITY</span></h2>
            <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/30">Bottom-Line Scorecard & Verdict</p>
          </div>
        </div>
        <div className="h-px flex-1 mx-12 bg-white/5" />
        <div className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-lg border border-white/10">
          <span className="text-[10px] font-black uppercase tracking-widest text-white/40">Technical Decision Matrix</span>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-8 z-10 flex-1 overflow-hidden">
        {/* Left: Scorecard Matrix */}
        <div className="col-span-6 bg-white/[0.02] border border-white/5 rounded-3xl p-6 flex flex-col">
          <div className="flex justify-between items-center mb-6 px-4">
            <h3 className="text-[10px] font-black uppercase tracking-widest text-white/40">Feature Roadmap Status</h3>
            <div className="flex gap-4">
               <span className="text-[8px] font-bold text-green-500 uppercase flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-green-500" /> Ready</span>
               <span className="text-[8px] font-bold text-orange-500 uppercase flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-orange-500" /> Limit</span>
               <span className="text-[8px] font-bold text-red-500 uppercase flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-red-500" /> Fail</span>
            </div>
          </div>
          
          <div className="space-y-1.5 overflow-y-auto pr-2 custom-scrollbar">
            {scorecard.map((row, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/[0.03] hover:bg-white/[0.08] transition-colors">
                <span className="text-xs font-bold text-white/70">{row.feature}</span>
                <div className="flex items-center gap-6">
                   <span className={`text-[10px] font-black uppercase tracking-widest ${row.color}`}>{row.quality}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Verdict & Recommendation */}
        <div className="col-span-6 flex flex-col gap-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-green-500/5 border border-green-500/10 rounded-2xl p-5">
              <h4 className="text-[10px] font-black text-green-500 uppercase tracking-widest mb-4">✅ Acceptable if</h4>
              <ul className="space-y-2 text-[10px] text-white/60 leading-tight">
                <li>• Testing model with &lt;50 artists</li>
                <li>• Accept manual operations (Interns)</li>
                <li>• Migration planned in 6-12 months</li>
                <li>• Fastest time-to-market is priority</li>
              </ul>
            </div>
            <div className="bg-red-500/5 border border-red-500/10 rounded-2xl p-5">
              <h4 className="text-[10px] font-black text-red-500 uppercase tracking-widest mb-4">❌ Not Acceptable if</h4>
              <ul className="space-y-2 text-[10px] text-white/60 leading-tight">
                <li>• Need true behavioral scoring</li>
                <li>• Automated splits are required</li>
                <li>• Scaling to 500+ immediately</li>
                <li>• Zero manual ops is the goal</li>
              </ul>
            </div>
          </div>

          <div className="flex-1 bg-[#FFB800] rounded-3xl p-8 text-black flex flex-col relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-3xl" />
            
            <span className="text-[10px] font-black uppercase tracking-[0.3em] mb-4 opacity-50">Strategic Recommendation</span>
            <h3 className="text-2xl font-black uppercase tracking-tighter mb-4 leading-none">
              GHL is a Proof-of-Concept vehicle, not a long-term platform.
            </h3>
            
            <div className="space-y-3 mt-2 mb-6">
              <p className="text-xs font-medium leading-relaxed opacity-70">
                Use it to validate the business model, generate initial revenue, and learn what features matter most to artists.
              </p>
            </div>

            <div className="mt-auto pt-6 border-t border-black/10 flex items-center justify-between">
               <div>
                  <span className="text-[10px] font-black uppercase opacity-40">MIGRATE AT</span>
                  <p className="text-sm font-black uppercase">50+ Artists / $10k+ MRR</p>
               </div>
               <svg className="w-8 h-8 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GHLVerdictSlide;
