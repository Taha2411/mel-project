
import React from 'react';
import { Waveform } from '../constants';

const IntegrationArchitectureSlide: React.FC = () => {
  return (
    <div className="relative w-full h-full flex flex-col p-10 text-white overflow-hidden bg-[#050607] rounded-[40px] border border-blue-500/30 shadow-2xl">
      <Waveform color="#3B82F6" />
      
      {/* Header Area */}
      <div className="w-full flex justify-between items-start mb-6 z-10">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-3">
             <span className="px-3 py-1 bg-blue-500/20 border border-blue-500/50 rounded-full text-[11px] font-black text-blue-400 tracking-[0.2em] uppercase">Technical Architecture</span>
             <div className="h-px w-16 bg-blue-500/30" />
          </div>
          <h2 className="text-5xl font-black tracking-tighter uppercase leading-tight text-white">
            INTEGRATED <span className="text-blue-500 italic">SYSTEM</span> ARCHITECTURE
          </h2>
          <p className="text-xs font-bold text-blue-300/60 uppercase tracking-[0.2em]">Full-Stack Data Flow & API Connectivity Matrix</p>
        </div>
        <div className="flex gap-4">
            <div className="bg-blue-500/10 border border-blue-500/30 px-5 py-2.5 rounded-2xl flex items-center gap-3 shadow-lg">
                <div className="w-2.5 h-2.5 rounded-full bg-blue-500 shadow-[0_0_15px_#3B82F6]" />
                <span className="text-xs font-black uppercase tracking-widest text-white">API Integration Layer ⭐</span>
            </div>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-10 z-10 flex-1 overflow-hidden">
        
        {/* Left Column: The Architecture Diagram */}
        <div className="col-span-7 flex flex-col gap-4">
          <div className="flex-1 bg-white/[0.03] border border-white/10 rounded-[32px] p-8 flex flex-col relative overflow-hidden shadow-inner">
            {/* Diagram Background Grid */}
            <div className="absolute inset-0 opacity-[0.05] pointer-events-none" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
            
            <div className="relative flex-1 flex flex-col gap-6 justify-center">
                
                {/* 1. Custom Platform Block */}
                <div className="border-2 border-blue-500/40 bg-blue-900/10 rounded-3xl p-6 flex flex-col gap-4 relative shadow-2xl backdrop-blur-sm">
                    <div className="absolute -top-3 left-6 bg-blue-500 px-3 py-0.5 rounded text-[10px] font-black text-black uppercase tracking-widest shadow-lg">Proprietary Asset</div>
                    <h3 className="text-[13px] font-black uppercase tracking-widest text-white border-b border-white/10 pb-3 mb-1 flex items-center gap-2">
                        <svg className="w-4 h-4 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>
                        CUSTOM PLATFORM (React/Node)
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="bg-black/60 border border-white/10 p-4 rounded-xl">
                            <span className="text-[10px] font-black text-blue-400 uppercase block mb-2 tracking-widest">Frontend UI</span>
                            <ul className="text-[11px] text-white/90 space-y-1 font-bold leading-tight">
                                <li>• Artist Hubs</li>
                                <li>• Drop Interface</li>
                                <li>• Superfan Portal</li>
                                <li>• Admin/Artist Dash</li>
                            </ul>
                        </div>
                        <div className="bg-black/60 border border-white/10 p-4 rounded-xl">
                            <span className="text-[10px] font-black text-blue-400 uppercase block mb-2 tracking-widest">Backend API</span>
                            <ul className="text-[11px] text-white/90 space-y-1 font-bold leading-tight">
                                <li>• Drop Lifecycle Engine</li>
                                <li>• Behavioral Scoring</li>
                                <li>• Analytics Engine</li>
                                <li>• GHL API Sync Layer ⭐</li>
                            </ul>
                        </div>
                    </div>
                </div>

                {/* 2. Database Connection Label */}
                <div className="flex justify-center -my-3 relative z-20">
                    <div className="bg-blue-600 px-6 py-2 rounded-xl border-2 border-[#050505] shadow-2xl">
                        <span className="text-[12px] font-black text-white uppercase tracking-widest">Primary DB: PostgreSQL</span>
                    </div>
                </div>

                {/* 3. Sync Layer Visual */}
                <div className="flex flex-col items-center py-2 relative">
                    <div className="h-10 w-px bg-gradient-to-b from-blue-500 to-emerald-500" />
                    <div className="bg-emerald-500 border-2 border-emerald-400/50 px-8 py-3 rounded-2xl shadow-[0_0_40px_rgba(16,185,129,0.3)] flex items-center gap-4 group hover:scale-105 transition-transform">
                        <svg className="w-5 h-5 text-black animate-spin-slow" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                        </svg>
                        <span className="text-[12px] font-black uppercase tracking-[0.2em] text-black italic">Two-Way API Sync Layer</span>
                        <svg className="w-5 h-5 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
                        </svg>
                    </div>
                    <div className="h-10 w-px bg-gradient-to-b from-emerald-500 to-blue-500" />
                </div>

                {/* 4. GHL Block */}
                <div className="border border-white/20 bg-white/[0.05] rounded-3xl p-6 flex flex-col gap-4 relative shadow-2xl">
                     <div className="absolute -top-3 left-6 bg-white/20 px-3 py-0.5 rounded text-[10px] font-black text-white uppercase tracking-widest shadow-lg backdrop-blur-md">Commodity Engine</div>
                     <h3 className="text-[13px] font-black uppercase tracking-widest text-white border-b border-white/10 pb-3 mb-1 flex items-center gap-2">
                        <svg className="w-4 h-4 text-white/60" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                        GOHIGHLEVEL (CRM ENGINE)
                     </h3>
                     <div className="grid grid-cols-2 gap-4">
                        <div className="bg-black/60 border border-white/10 p-4 rounded-xl">
                            <span className="text-[10px] font-black text-white/50 uppercase block mb-2 tracking-widest">Core Database</span>
                            <ul className="text-[11px] text-white/80 space-y-1 font-bold leading-tight">
                                <li>• Contact/Fan Profiles</li>
                                <li>• Tags & Segments</li>
                                <li>• Artist Sub-Accounts</li>
                                <li>• Contact History</li>
                            </ul>
                        </div>
                        <div className="bg-black/60 border border-white/10 p-4 rounded-xl">
                            <span className="text-[10px] font-black text-white/50 uppercase block mb-2 tracking-widest">Comm Tools</span>
                            <ul className="text-[11px] text-white/80 space-y-1 font-bold leading-tight">
                                <li>• Email/SMS Automation</li>
                                <li>• Workflow Engines</li>
                                <li>• Lead Capture Forms</li>
                                <li>• Appointment Engine</li>
                            </ul>
                        </div>
                    </div>
                </div>

                {/* 5. External APIs */}
                <div className="mt-2 flex justify-center gap-4">
                    {['Stripe', 'SendGrid', 'Twilio', 'AWS S3'].map(api => (
                        <div key={api} className="px-5 py-2.5 bg-white/5 border border-white/20 rounded-xl flex items-center gap-2.5 hover:bg-white/10 transition-colors shadow-md">
                            <div className="w-2 h-2 rounded-full bg-blue-400/50 shadow-[0_0_5px_#3B82F6]" />
                            <span className="text-[11px] font-black uppercase text-white/70 tracking-widest">{api}</span>
                        </div>
                    ))}
                </div>
            </div>
          </div>
        </div>

        {/* Right Column: Strategic Details - Maximized Visibility */}
        <div className="col-span-5 flex flex-col gap-5 overflow-y-auto pr-2 custom-scrollbar pb-10">
          
          {/* SYNC LOGIC BOX */}
          <div className="bg-emerald-500/10 border-2 border-emerald-500/30 rounded-3xl p-7 shadow-xl">
            <h3 className="text-[12px] font-black uppercase tracking-[0.3em] text-emerald-400 mb-5 flex items-center gap-3">
                <div className="p-1.5 bg-emerald-500/20 rounded-lg">
                    <svg className="w-5 h-5 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>
                </div>
                BI-DIRECTIONAL SYNC LOGIC
            </h3>
            <div className="space-y-6">
                <div>
                    <span className="text-[11px] font-black text-emerald-400 uppercase block mb-3 underline underline-offset-8 decoration-emerald-500/30 tracking-widest italic">Platform → GHL</span>
                    <ul className="text-[12px] font-bold text-white leading-relaxed space-y-2">
                        <li className="flex gap-2"><span>•</span> <span>Fan Registration creates GHL contact record</span></li>
                        <li className="flex gap-2"><span>•</span> <span>Engagement scores update GHL custom fields</span></li>
                        <li className="flex gap-2"><span>•</span> <span>Thresholds trigger GHL welcome/nurture flows</span></li>
                        <li className="flex gap-2"><span>•</span> <span>Superfan upgrades apply exclusive member tags</span></li>
                    </ul>
                </div>
                <div className="h-px bg-white/5" />
                <div>
                    <span className="text-[11px] font-black text-white uppercase block mb-3 underline underline-offset-8 decoration-white/20 tracking-widest italic">GHL → Platform</span>
                    <ul className="text-[12px] font-bold text-white/90 leading-relaxed space-y-2">
                        <li className="flex gap-2"><span>•</span> <span>Email Opens/Clicks sync back to activity logs</span></li>
                        <li className="flex gap-2"><span>•</span> <span>Appointments sync to Artist & Fan dashboards</span></li>
                        <li className="flex gap-2"><span>•</span> <span>SMS responses logged for sentiment analysis</span></li>
                    </ul>
                </div>
            </div>
          </div>

          {/* DATA SPLIT BOX */}
          <div className="bg-blue-600/5 border-2 border-blue-500/20 rounded-3xl p-7 shadow-xl">
            <h3 className="text-[12px] font-black uppercase tracking-[0.3em] text-blue-400 mb-5 flex items-center gap-3">
                <div className="p-1.5 bg-blue-500/20 rounded-lg">
                    <svg className="w-5 h-5 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                </div>
                DATA SPLIT STRATEGY
            </h3>
            <div className="grid grid-cols-1 gap-5">
                <div className="p-5 bg-black/60 rounded-2xl border-l-4 border-blue-500 shadow-lg">
                    <span className="text-[11px] font-black text-blue-400 uppercase block mb-2 tracking-widest italic">PostgreSQL (The Proprietary Brain)</span>
                    <p className="text-[12px] font-bold text-white leading-relaxed">
                        Stores Media Assets, Drop Lifecycle Logic, Real-time Engagement Scores, and Platform-wide cross-pollination metrics.
                    </p>
                </div>
                <div className="p-5 bg-black/60 rounded-2xl border-l-4 border-white/30 shadow-lg">
                    <span className="text-[11px] font-black text-white/60 uppercase block mb-2 tracking-widest italic">GHL (The Commodity Engine)</span>
                    <p className="text-[12px] font-bold text-white/80 leading-relaxed">
                        Stores Contact PII, Email/SMS threads, Workflow states, Calendars, and Member tagging for automated comms.
                    </p>
                </div>
            </div>
          </div>

          {/* SUMMARY BOX - HIGH IMPACT */}
          <div className="bg-blue-600 rounded-[32px] p-8 text-black shadow-[0_20px_50px_rgba(37,99,235,0.4)] relative overflow-hidden group hover:brightness-110 transition-all">
             <div className="absolute top-0 right-0 w-48 h-48 bg-white/20 rounded-full -mr-24 -mt-24 blur-3xl opacity-50" />
             <div className="relative z-10">
                <h4 className="text-[11px] font-black uppercase tracking-[0.4em] mb-3 opacity-40 italic">Strategic Verdict</h4>
                <h3 className="text-3xl font-black uppercase tracking-tighter leading-none mb-5">Build Unique • Buy Commodity</h3>
                <p className="text-[13px] font-black leading-relaxed text-black/90 uppercase tracking-tight">
                    Leverage $100M+ in pre-built GHL R&D for infrastructure while we maintain 100% control of our proprietary Fan-Behavior and Media-Drop engine.
                </p>
             </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default IntegrationArchitectureSlide;
