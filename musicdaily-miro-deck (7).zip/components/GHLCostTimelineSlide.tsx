
import React from 'react';
import { Waveform } from '../constants';

const GHLCostTimelineSlide: React.FC = () => {
  const setupTasks = [
    "Sub-account architecture",
    "Community templates (30 artists)",
    "Workflow automation (50+ flows)",
    "Drop management system",
    "Payment & Stripe integration",
    "Email/SMS brand templates",
    "Landing page master designs",
    "Admin dashboard & SOPs"
  ];

  const timelinePhases = [
    { weeks: "01-02", title: "Architecture", desc: "Core engine setup & sub-account logic" },
    { weeks: "03-04", title: "Templates", desc: "Artist onboarding & hub design" },
    { weeks: "05-06", title: "Refinement", desc: "QA, testing & workflow hardening" },
    { weeks: "07", title: "Genesis", desc: "Launch with first 10 beta artists" },
  ];

  return (
    <div className="relative w-full h-full flex flex-col p-12 text-white overflow-hidden bg-[#0D0D0D] rounded-3xl border border-white/5 shadow-2xl">
      <Waveform />
      
      {/* Header */}
      <div className="w-full flex justify-between items-center mb-10 z-10">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-[#FFB800] rounded-xl flex items-center justify-center shadow-[0_0_25px_rgba(255,184,0,0.3)]">
            <span className="text-black font-black text-sm">10</span>
          </div>
          <div>
            <h2 className="text-2xl font-black tracking-tight uppercase">PATH A: <span className="text-[#FFB800]">INVESTMENT REQUIRED</span></h2>
            <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/30">Budget Allocation & Rollout Schedule</p>
          </div>
        </div>
        <div className="h-px flex-1 mx-12 bg-white/5" />
        <div className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-lg border border-white/10">
          <span className="text-[10px] font-black uppercase tracking-widest text-white/40">Financial Roadmap</span>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-8 z-10 flex-1">
        {/* Left: Financials */}
        <div className="col-span-6 flex flex-col gap-6">
          <div className="bg-white/5 border border-white/10 rounded-3xl p-8 flex flex-col h-full relative group hover:border-[#FFB800]/30 transition-all">
            <div className="flex justify-between items-start mb-8">
              <div>
                <span className="text-[10px] font-black uppercase text-[#FFB800] tracking-widest mb-1 block">Setup Cost (One-Time)</span>
                <h3 className="text-5xl font-black tracking-tighter">$3,000 — $6,000</h3>
              </div>
              <div className="p-3 bg-[#FFB800]/10 rounded-xl text-[#FFB800]">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-x-6 gap-y-3 mb-8">
              {setupTasks.map((task, i) => (
                <div key={i} className="flex items-center gap-2 text-[11px] font-bold text-white/40 group-hover:text-white/70 transition-colors uppercase tracking-tight">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#FFB800]/40 group-hover:bg-[#FFB800] transition-colors" />
                  {task}
                </div>
              ))}
            </div>

            <div className="mt-auto pt-8 border-t border-white/5">
              <span className="text-[10px] font-black uppercase text-white/20 tracking-widest mb-4 block">Monthly Burn Estimate</span>
              <div className="flex items-center gap-10">
                <div>
                   <span className="text-[9px] font-bold text-white/40 block">LICENSE</span>
                   <span className="text-xl font-black">$497</span>
                </div>
                <div>
                   <span className="text-[9px] font-bold text-white/40 block">DATA/COMMS</span>
                   <span className="text-xl font-black">~$300</span>
                </div>
                <div className="ml-auto text-right">
                   <span className="text-[9px] font-bold text-[#FFB800] block uppercase">Total / Mo</span>
                   <span className="text-2xl font-black text-[#FFB800]">$800 - $1K</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Timeline */}
        <div className="col-span-6 flex flex-col gap-6">
          <div className="bg-white/5 border border-white/10 rounded-3xl p-8 flex flex-col h-full relative overflow-hidden group hover:border-[#FFB800]/30 transition-all">
            <h3 className="text-[10px] font-black uppercase text-[#FFB800] tracking-widest mb-8 block">Implementation Schedule</h3>
            
            <div className="space-y-6 flex-1 relative">
              {/* Vertical line connecting phases */}
              <div className="absolute left-6 top-4 bottom-4 w-px bg-white/10 z-0" />
              
              {timelinePhases.map((phase, i) => (
                <div key={i} className="flex items-start gap-8 z-10 relative group/item">
                  <div className="w-12 h-12 bg-[#1A1A1A] rounded-xl flex items-center justify-center border border-white/10 text-[10px] font-black text-white/40 group-hover/item:text-[#FFB800] group-hover/item:border-[#FFB800]/40 transition-colors shadow-lg">
                    {phase.weeks}
                  </div>
                  <div>
                    <h4 className="text-sm font-black uppercase tracking-widest text-white/90 group-hover/item:text-white transition-colors">{phase.title}</h4>
                    <p className="text-[11px] text-white/40 leading-relaxed max-w-xs">{phase.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 pt-8 border-t border-white/5 flex items-center justify-between">
               <div>
                  <span className="text-[10px] font-black uppercase text-white/30 block mb-1">Target Launch</span>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    <span className="text-xl font-black uppercase tracking-tighter">6-8 WEEKS FROM START</span>
                  </div>
               </div>
               <div className="text-right">
                  <span className="text-[10px] font-black uppercase text-white/30 block mb-1">Status</span>
                  <span className="text-xs font-bold uppercase tracking-widest bg-green-500/20 text-green-400 px-3 py-1 rounded-full border border-green-500/20">Awaiting Greenlight</span>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GHLCostTimelineSlide;
