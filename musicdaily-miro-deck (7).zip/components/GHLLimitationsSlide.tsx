
import React from 'react';
import { Waveform } from '../constants';

const GHLLimitationsSlide: React.FC = () => {
  const limitations = [
    {
      id: "01",
      title: "Non-Native Drops",
      problem: "No centralized database or lifecycle engine exists for 'Drops'.",
      reality: "Every drop is a manual build of pages, workflows, and tags.",
      impact: "Human error becomes a systemic risk. Not viable beyond 50 artists.",
      status: "OPS HEAVY"
    },
    {
      id: "02",
      title: "Static Scoring",
      problem: "No real-time behavioral decay or predictive engagement engines.",
      reality: "Scoring is limited to simple binary tags based on clicks/opens.",
      impact: "You'll be 'flying blind' on true superfan loyalty metrics.",
      status: "LOW INTEL"
    },
    {
      id: "03",
      title: "Manual Finance",
      problem: "No automated 80/20 revenue splits or artist-linked accounts.",
      reality: "All cash hits MD account first. Manual bookkeeping & payouts.",
      impact: "Huge operational burden. Requires full-time finance admin.",
      status: "HIGH FRICTION"
    },
    {
      id: "04",
      title: "Data Silos",
      problem: "No cross-artist analytics or platform-wide health dashboards.",
      reality: "Reporting is siloed per sub-account. No cohort analysis.",
      impact: "No visibility into the network effect or platform-wide retention.",
      status: "SILOED DATA"
    },
    {
      id: "05",
      title: "Basic Community",
      problem: "No gamification, user reputation, or algorithmic feeds.",
      reality: "Basically just a Facebook wall. No organic 'stickiness'.",
      impact: "Relies entirely on external SMS/Email to bring fans back.",
      status: "LOW RETENTION"
    },
    {
      id: "06",
      title: "Scale Ceiling",
      problem: "Infrastructure not optimized for high-volume multi-tenancy.",
      reality: "API rate limits and workflow delays kick in at scale.",
      impact: "The system will likely fail or experience lag above 100 artists.",
      status: "HARD CEILING"
    }
  ];

  return (
    <div className="relative w-full h-full flex flex-col p-12 text-white overflow-hidden bg-[#0A0A0A] rounded-3xl border border-red-500/20 shadow-2xl">
      <Waveform />
      
      {/* Header */}
      <div className="w-full flex justify-between items-center mb-10 z-10">
        <div className="flex items-center gap-5">
          <div className="w-12 h-12 bg-red-600 rounded-2xl flex items-center justify-center shadow-[0_0_30px_rgba(220,38,38,0.4)] animate-pulse">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <div>
            <h2 className="text-3xl font-black tracking-tighter uppercase leading-none">PATH A: <span className="text-red-500">CRITICAL LIMITATIONS</span></h2>
            <p className="text-[10px] font-bold uppercase tracking-[0.5em] text-white/30 mt-2">The Hidden Operational Costs of GHL</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3 px-5 py-2.5 bg-red-500/10 rounded-xl border border-red-500/20">
          <span className="text-xs font-black uppercase tracking-widest text-red-500">Architectural Constraints</span>
        </div>
      </div>

      {/* Limitation Grid */}
      <div className="grid grid-cols-3 gap-6 z-10 flex-1 content-start">
        {limitations.map((limit, idx) => (
          <div key={idx} className="bg-[#141414] border border-white/5 rounded-2xl p-6 flex flex-col hover:border-red-500/30 transition-all duration-300 group shadow-lg">
            <div className="flex justify-between items-start mb-6">
              <span className="text-[10px] font-black text-white/20 font-mono tracking-widest">#{limit.id}</span>
              <span className="px-2 py-0.5 rounded-md bg-red-500/10 text-red-500 text-[8px] font-black uppercase tracking-widest border border-red-500/20 group-hover:bg-red-500 group-hover:text-black transition-colors">
                {limit.status}
              </span>
            </div>

            <h3 className="text-sm font-black uppercase tracking-wider text-white mb-3">{limit.title}</h3>
            
            <div className="space-y-4 flex-1">
              <div>
                <p className="text-[10px] text-white/40 leading-relaxed italic border-l-2 border-red-500/20 pl-3">
                  {limit.problem}
                </p>
              </div>

              <div className="bg-white/5 rounded-xl p-4 border border-white/5">
                <span className="text-[8px] font-black uppercase tracking-[0.2em] text-white/30 block mb-2">Operational Reality</span>
                <p className="text-[11px] font-semibold text-white/80 leading-snug">
                  {limit.reality}
                </p>
              </div>
            </div>

            <div className="mt-5 pt-4 border-t border-white/5">
              <div className="flex items-start gap-2">
                <span className="text-red-500 font-bold text-xs mt-0.5">⚠️</span>
                <div>
                  <span className="text-[9px] font-black uppercase text-red-500/60 block tracking-tighter">Strategic Impact</span>
                  <p className="text-[10px] text-white/60 font-medium italic">{limit.impact}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Footer Warning */}
      <div className="z-10 mt-10 p-6 bg-red-500/5 border border-red-500/10 rounded-3xl flex items-center justify-between">
        <div className="flex flex-col">
          <span className="text-xs font-black uppercase tracking-[0.2em] text-red-500 mb-1">Warning: Technical Debt</span>
          <p className="text-sm text-white/50">Choosing Path A accepts these constraints as <u>Permanent Features</u> of the V1 architecture.</p>
        </div>
        <div className="flex items-center gap-6">
            <div className="text-right">
                <span className="text-[9px] font-black uppercase text-white/20 block">Max Scale</span>
                <span className="text-xl font-black text-red-500 tracking-tighter">~50 ARTISTS</span>
            </div>
            <div className="w-px h-10 bg-white/10" />
            <div className="text-right">
                <span className="text-[9px] font-black uppercase text-white/20 block">Maintenance</span>
                <span className="text-xl font-black text-red-500 tracking-tighter">VERY HIGH</span>
            </div>
        </div>
      </div>
    </div>
  );
};

export default GHLLimitationsSlide;
