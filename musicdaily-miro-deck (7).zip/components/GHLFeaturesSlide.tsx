
import React from 'react';
import { Waveform } from '../constants';

const GHLFeaturesSlide: React.FC = () => {
  const sections = [
    {
      title: "Fan Registration",
      icon: <UserGroupIcon />,
      items: [
        "Email/password authentication",
        "Fan profiles with custom data fields",
        "Tag-based segmentation (Regular vs Superfan)",
        "Artist isolation via sub-accounts"
      ]
    },
    {
      title: "Artist Hubs",
      icon: <ChatBubbleIcon />,
      items: [
        "Dedicated communities per artist",
        "Public announcement & event channels",
        "Exclusive Superfan-only private rooms",
        "Native iOS/Android mobile app access"
      ]
    },
    {
      title: "Subscriptions",
      icon: <CreditCardIcon />,
      items: [
        "Full Stripe integration & tracking",
        "Recurring monthly subscription models",
        "Automated billing & renewal cycles",
        "Transparent revenue reporting per artist"
      ]
    },
    {
      title: "Drops System",
      icon: <RocketIcon />,
      items: [
        "Time-based scheduling (Pre → Live → Expired)",
        "Automated gating by fan membership level",
        "Branded landing pages for every drop",
        "Engagement & click-through tracking"
      ]
    },
    {
      title: "Marketing Automation",
      icon: <ZapIcon />,
      items: [
        "Multi-channel welcome & nurture flows",
        "Automated drop & event notifications",
        "Dunning management for failed payments",
        "SMS & Email broadcast capabilities"
      ]
    },
    {
      title: "Deep Analytics",
      icon: <ChartBarIcon />,
      items: [
        "Real-time contact counts per artist",
        "Detailed email open & click metrics",
        "Individual fan purchase & behavior history",
        "Projected MRR & revenue dashboards"
      ]
    },
    {
      title: "Cross-Pollination",
      icon: <LinkIcon />,
      items: [
        "Curated 'Favorite Artists' navigation",
        "Static promotion modules for ecosystem discovery",
        "UTM-based attribution for fan sources",
        "Network-wide fan tagging & tracking"
      ]
    },
    {
      title: "Custom Branding",
      icon: <ColorPaletteIcon />,
      items: [
        "Custom root domains per artist brand",
        "White-labeled UI & custom color palettes",
        "Artist-specific logos & asset libraries",
        "Enterprise-grade SSL certificates"
      ]
    }
  ];

  return (
    <div className="relative w-full h-full flex flex-col p-12 text-white overflow-hidden bg-[#0D0D0D] rounded-3xl border border-white/5 shadow-2xl">
      <Waveform />
      
      {/* Header */}
      <div className="w-full flex justify-between items-center mb-10 z-10">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-[#10B981] rounded-xl flex items-center justify-center shadow-[0_0_25px_rgba(16,185,129,0.4)]">
            <span className="text-white font-black text-sm">07</span>
          </div>
          <div>
            <h2 className="text-2xl font-black tracking-tight">PATH A: WHAT WE <span className="text-[#10B981]">CAN BUILD</span> IN GHL</h2>
            <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-white/30">Capabilities & Feature Matrix</p>
          </div>
        </div>
        <div className="h-px flex-1 mx-12 bg-white/5" />
        <div className="flex items-center gap-2 px-4 py-2 bg-green-500/10 rounded-lg border border-green-500/20">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-[10px] font-black uppercase tracking-widest text-green-400">V1 MVP Ready</span>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-6 z-10 flex-1 content-start">
        {sections.map((section, idx) => (
          <div key={idx} className="bg-[#1A1A1A] border border-white/5 rounded-2xl p-6 hover:border-green-500/40 hover:bg-[#222] transition-all duration-300 group shadow-lg">
            <div className="flex items-center gap-3 mb-5">
              <div className="text-green-500 transition-transform group-hover:scale-110">
                {section.icon}
              </div>
              <h3 className="text-xs font-black uppercase tracking-wider text-white/90">{section.title}</h3>
            </div>
            <ul className="space-y-2.5">
              {section.items.map((item, i) => (
                <li key={i} className="flex items-start gap-2 text-[11px] text-white/40 group-hover:text-white/70 transition-colors leading-relaxed">
                  <svg className="w-3.5 h-3.5 text-green-500/60 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                  </svg>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="z-10 mt-8 flex items-center justify-center gap-8 text-white/20 font-bold text-[9px] uppercase tracking-[0.3em] border-t border-white/5 pt-8">
        <span>Fast Implementation</span>
        <div className="w-1.5 h-1.5 rounded-full bg-white/10" />
        <span>Proven Infrastructure</span>
        <div className="w-1.5 h-1.5 rounded-full bg-white/10" />
        <span>Scalable V1 Model</span>
      </div>
    </div>
  );
};

// Custom SVG Icons for better design consistency
const UserGroupIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
  </svg>
);

const ChatBubbleIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
  </svg>
);

const CreditCardIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a2 2 0 002-2V7a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
  </svg>
);

const RocketIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.536 8.464L19.071 4.93M9.172 14.828l-3.535 3.536m10.607-10.607l3.535-3.535m-3.535 10.606l3.535 3.535M21 3l-6 6m6-6l-6 6m13 0h-2.586a1 1 0 01-.707-.293l-2.414-2.414a1 1 0 00-.707-.293h-3.172a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293H3" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
  </svg>
);

const ZapIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
  </svg>
);

const ChartBarIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
  </svg>
);

const LinkIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
  </svg>
);

const ColorPaletteIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
  </svg>
);

export default GHLFeaturesSlide;
