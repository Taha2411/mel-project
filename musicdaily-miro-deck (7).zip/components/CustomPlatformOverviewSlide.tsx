
import React from 'react';
import { Waveform } from '../constants';

const CustomPlatformOverviewSlide: React.FC = () => {
  const techStack = [
    { label: "Architecture", sub: "Node.js / Python / Go", icon: <CodeIcon /> },
    { label: "Data Engine", sub: "PostgreSQL / Redis", icon: <DatabaseIcon /> },
    { label: "Experience", sub: "Next.js 15 / React", icon: <LayoutIcon /> },
    { label: "Infrastructure", sub: "AWS Cloud Native", icon: <ServerIcon /> },
    { label: "Ledger", sub: "Full Stripe Automation", icon: <CreditCardIcon /> },
    { label: "Intelligence", sub: "Proprietary Scoring", icon: <ZapIcon /> },
  ];

  const valueProps = [
    { title: "Zero Compromises", desc: "No platform limits. Your exact workflow mapped to high-performance code." },
    { title: "Infinite Scale", desc: "Engineered for high concurrency. Zero lag at 10,000+ artists." },
    { title: "Full Automation", desc: "Revenue payouts and behavioral analytics happen entirely while you sleep." },
    { title: "Investor-Ready", desc: "A tangible IP asset that builds massive enterprise valuation for the company." },
  ];

  return (
    <div className="relative w-full h-full flex flex-col p-12 text-white overflow-hidden bg-[#050706] rounded-[40px] border border-emerald-500/20 shadow-2xl">
      {/* Refined Background Elements for better contrast */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(16,185,129,0.05),transparent_60%)]" />
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-emerald-500/5 blur-[100px] rounded-full -mr-32 -mt-32" />
      <Waveform color="#10B981" />
      
      {/* Header Section */}
      <div className="w-full flex justify-between items-end mb-10 z-10">
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-3">
             <span className="px-3 py-1 bg-emerald-500/20 border border-emerald-500/40 rounded-full text-[11px] font-black text-emerald-400 tracking-[0.2em] uppercase">Strategic Path B</span>
             <div className="h-px w-16 bg-emerald-500/20" />
          </div>
          <h2 className="text-6xl font-black tracking-tighter uppercase leading-none">
            The <span className="text-emerald-500">Custom</span> Asset
          </h2>
        </div>
        <div className="flex flex-col items-end">
            <div className="text-[10px] font-black text-white/40 tracking-[0.3em] uppercase mb-2">Platform Strategy</div>
            <div className="px-6 py-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center gap-3 shadow-lg backdrop-blur-md">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-[0_0_12px_#10B981]" />
                <span className="text-xs font-black uppercase tracking-widest text-white italic">Proprietary IP</span>
            </div>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-10 z-10 flex-1">
        {/* Left Section: Blueprint Layout */}
        <div className="col-span-7 flex flex-col gap-6">
          <div className="relative flex-1 bg-white/[0.04] backdrop-blur-xl border border-white/10 rounded-[32px] p-10 overflow-hidden shadow-inner group transition-all duration-500">
            {/* Grid Decoration - Further Subdued for readability */}
            <div className="absolute inset-0 opacity-[0.02] pointer-events-none" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
            
            <div className="relative z-10">
                <div className="flex justify-between items-center mb-10 border-b border-white/10 pb-5">
                    <h3 className="text-xs font-black uppercase tracking-[0.3em] text-emerald-500">System Architecture</h3>
                    <span className="text-[10px] font-mono text-white/30 uppercase tracking-widest">v1.0.0_PRODUCTION</span>
                </div>
                
                <div className="grid grid-cols-2 gap-x-12 gap-y-10">
                    {techStack.map((tech, i) => (
                        <div key={i} className="flex gap-5 items-center group/item">
                            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover/item:bg-emerald-500 group-hover/item:text-black transition-all duration-400 shadow-lg">
                                {tech.icon}
                            </div>
                            <div className="flex flex-col">
                                <span className="text-sm font-black uppercase tracking-tight text-white/95 leading-none mb-1.5">{tech.label}</span>
                                <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">{tech.sub}</span>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="mt-12 flex flex-col gap-4 p-6 bg-black/40 rounded-2xl border border-white/5">
                    <span className="text-[10px] font-black text-emerald-500/60 uppercase tracking-[0.2em]">100% Asset Ownership</span>
                    <div className="flex flex-wrap gap-3">
                        {["GitHub Repository", "AWS Root Access", "Stripe Connect", "Proprietary Data"].map(item => (
                            <div key={item} className="flex items-center gap-2">
                                <svg className="w-3 h-3 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M5 13l4 4L19 7" /></svg>
                                <span className="text-[10px] font-bold text-white/70 uppercase tracking-wide">
                                    {item}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
          </div>
        </div>

        {/* Right Section: Strategic Pillars with Improved Contrast */}
        <div className="col-span-5 flex flex-col gap-4">
            {valueProps.map((prop, i) => (
                <div key={i} className="flex-1 bg-white/[0.03] border border-white/10 rounded-3xl px-7 py-6 transition-all hover:bg-white/[0.06] group shadow-lg">
                    <div className="flex items-center gap-4 mb-2.5">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]" />
                        <h4 className="text-[13px] font-black uppercase tracking-widest text-emerald-400">{prop.title}</h4>
                    </div>
                    <p className="text-[12px] font-medium text-white/70 leading-relaxed group-hover:text-white transition-colors">
                        {prop.desc}
                    </p>
                </div>
            ))}

            <div className="mt-4 p-8 bg-emerald-500 rounded-[32px] text-black relative overflow-hidden shadow-2xl">
                <div className="absolute top-0 right-0 w-40 h-40 bg-white/20 rounded-full -mr-20 -mt-20 blur-3xl opacity-60" />
                <div className="relative z-10 flex flex-col gap-4">
                    <div className="flex justify-between items-start">
                        <div className="flex flex-col gap-1">
                            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-black/40 block">Business Outcome</span>
                            <h3 className="text-3xl font-black uppercase tracking-tighter leading-none italic">Asset over Expense</h3>
                        </div>
                        <div className="px-3 py-1.5 bg-black/10 rounded-xl border border-black/5">
                            <span className="text-[10px] font-black uppercase tracking-widest">TIER 1 EQUITY</span>
                        </div>
                    </div>
                    <p className="text-[12px] font-bold leading-relaxed text-black/80">
                        Stop paying monthly rent for limited tools. Invest in proprietary equity that increases your company valuation by 3x - 5x.
                    </p>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

const CodeIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg>;
const DatabaseIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" /></svg>;
const LayoutIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" /></svg>;
const ServerIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" /></svg>;
const CreditCardIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a2 2 0 002-2V7a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>;
const ZapIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>;

export default CustomPlatformOverviewSlide;
