
import React from 'react';
import { Waveform } from '../constants';

const HybridArchitectureSlide: React.FC = () => {
  return (
    <div className="relative w-full h-full flex flex-col p-10 text-white overflow-hidden bg-[#080808] rounded-[40px] border border-white/10 shadow-2xl">
      <Waveform color="#3B82F6" />
      
      {/* Header */}
      <div className="w-full flex justify-between items-start mb-6 z-10">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-3">
             <span className="px-3 py-1 bg-blue-500/20 border border-blue-500/40 rounded-full text-[10px] font-black text-blue-400 tracking-[0.2em] uppercase">Architecture Blueprint</span>
             <div className="h-px w-12 bg-blue-500/20" />
          </div>
          <h2 className="text-4xl font-black tracking-tighter uppercase leading-tight">
            THREE-TIER <span className="text-blue-500 italic">HYBRID</span> ARCHITECTURE
          </h2>
          <p className="text-xs font-bold text-white/30 uppercase tracking-widest italic">Optimizing Proprietary UX with Proven Infrastructure</p>
        </div>
        <div className="bg-white/5 border border-white/10 px-4 py-2 rounded-2xl">
            <span className="text-[10px] font-black text-[#FFB800] uppercase block mb-1">Implementation Focus</span>
            <span className="text-xs font-bold text-white uppercase tracking-tighter italic">"Build Unique, Buy Commodity"</span>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6 z-10 flex-1 overflow-hidden">
        {/* Left: The Visual Pyramid & GHL Foundation */}
        <div className="col-span-4 flex flex-col gap-2 justify-center items-center">
          
          {/* TIER 3: SUPERFAN (TOP - GOLD) */}
          <div className="w-[60%] h-24 bg-[#FFB800] rounded-t-3xl border-b border-black/10 flex flex-col items-center justify-center text-black shadow-[0_0_30px_rgba(255,184,0,0.2)]">
            <span className="text-[9px] font-black uppercase tracking-widest opacity-40">Tier 03</span>
            <h4 className="text-sm font-black uppercase tracking-tight">SUPERFAN</h4>
            <div className="w-8 h-0.5 bg-black/20 my-1" />
            <span className="text-[8px] font-bold uppercase tracking-widest opacity-60">Premium State</span>
          </div>

          {/* TIER 2: ARTIST HUB (MIDDLE - MEDIUM GRAY) */}
          <div className="w-[85%] h-28 bg-[#2A2A2A] border-y border-white/5 flex flex-col items-center justify-center shadow-lg">
            <span className="text-[9px] font-black uppercase tracking-widest text-white/20">Tier 02</span>
            <h4 className="text-sm font-black uppercase tracking-tight text-white/90">ARTIST HUB</h4>
            <div className="w-12 h-0.5 bg-white/5 my-1" />
            <span className="text-[8px] font-bold uppercase tracking-widest text-blue-400">Custom Frontend</span>
          </div>

          {/* TIER 1: EDITORIAL (BASE - LIGHT GRAY) */}
          <div className="w-full h-24 bg-[#4A4A4A] rounded-b-2xl border-t border-white/5 flex flex-col items-center justify-center shadow-lg">
            <span className="text-[9px] font-black uppercase tracking-widest text-white/20">Tier 01</span>
            <h4 className="text-sm font-black uppercase tracking-tight text-white/80">EDITORIAL FRONT</h4>
            <div className="w-16 h-0.5 bg-white/5 my-1" />
            <span className="text-[8px] font-bold uppercase tracking-widest text-white/40 italic">Discovery Engine</span>
          </div>

          {/* FOUNDATION: GHL (BASE SLAB - BLUE) */}
          <div className="w-full mt-4 h-32 bg-blue-600 rounded-2xl p-6 border-t-4 border-blue-400 shadow-[0_20px_40px_rgba(30,64,175,0.4)] relative overflow-hidden flex flex-col items-center justify-center">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.1),transparent_70%)]" />
            <h3 className="text-md font-black uppercase tracking-widest text-white mb-2 relative z-10">GHL FOUNDATION</h3>
            <div className="flex gap-4 relative z-10">
                <div className="flex flex-col items-center"><span className="text-[10px] font-black">CRM</span></div>
                <div className="w-px h-4 bg-white/20" />
                <div className="flex flex-col items-center"><span className="text-[10px] font-black">EMAILS</span></div>
                <div className="w-px h-4 bg-white/20" />
                <div className="flex flex-col items-center"><span className="text-[10px] font-black">AUTOMATION</span></div>
            </div>
            <div className="mt-4 px-3 py-1 bg-black/20 rounded-full border border-white/10 relative z-10">
                <span className="text-[8px] font-black uppercase tracking-[0.2em] text-white/60">Two-Way API Sync Layer</span>
            </div>
          </div>
        </div>

        {/* Right: Detailed Content Cards (High Visibility) */}
        <div className="col-span-8 flex flex-col gap-3 overflow-y-auto pr-2 custom-scrollbar pb-10">
          
          {/* TIER 3 CONTENT */}
          <div className="bg-[#FFB800] p-5 rounded-2xl text-black shadow-xl">
            <div className="flex justify-between items-center mb-3">
                <h3 className="text-sm font-black uppercase tracking-widest">TIER 3: SUPERFAN STATE (Premium)</h3>
                <span className="text-[10px] font-bold px-2 py-0.5 bg-black/10 rounded uppercase">Members Only</span>
            </div>
            <div className="grid grid-cols-2 gap-x-6 gap-y-1">
                <Bullet dark text="All Tier 2 features PLUS" />
                <Bullet dark text="Early access to drops (pre-release)" />
                <Bullet dark text="Exclusive merchandise portal" />
                <Bullet dark text="Behind-the-scenes content feed" />
                <Bullet dark text="Direct artist messaging access" />
                <Bullet dark text="Live streams & virtual events" />
                <Bullet dark text="Premium badge & community status" />
                <Bullet dark text="Priority physical event access" />
            </div>
          </div>

          {/* TIER 2 CONTENT */}
          <div className="bg-[#2A2A2A] p-5 rounded-2xl border border-white/10 shadow-xl">
            <div className="flex justify-between items-center mb-3">
                <h3 className="text-sm font-black uppercase tracking-widest text-white/90">TIER 2: ARTIST HUB (Regular Fans)</h3>
                <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-500/20 text-blue-400 rounded uppercase border border-blue-500/20">Custom Frontend</span>
            </div>
            <div className="grid grid-cols-2 gap-x-6 gap-y-1">
                <Bullet text="Modern React UI/UX Design" />
                <Bullet text="Artist profiles & rich bio media" />
                <Bullet text="Public drops (releases, tours, events)" />
                <Bullet text="Interactive Community feed" />
                <Bullet text="Superfan content preview (locked)" />
                <Bullet text="5 favorite artists (cross-pollination)" />
                <Bullet text="Upgrade to Superfan CTA / Checkout" />
                <Bullet text="POWERED BY: PostgreSQL + GHL CRM" />
            </div>
          </div>

          {/* TIER 1 CONTENT */}
          <div className="bg-[#1A1A1A] p-5 rounded-2xl border border-white/5 shadow-xl">
            <div className="flex justify-between items-center mb-3">
                <h3 className="text-sm font-black uppercase tracking-widest text-white/60">TIER 1: EDITORIAL FRONT (MusicDaily.com)</h3>
                <span className="text-[10px] font-bold px-2 py-0.5 bg-white/5 text-white/30 rounded uppercase">Public Access</span>
            </div>
            <div className="grid grid-cols-2 gap-x-6 gap-y-1">
                <Bullet dim text="Public content site (WordPress)" />
                <Bullet dim text="Artist discovery news & features" />
                <Bullet dim text="Searchable global artist portals" />
                <Bullet dim text="Central login/auth gateway" />
            </div>
          </div>

          {/* FOUNDATION: GHL CONTENT */}
          <div className="bg-blue-600/10 border border-blue-500/40 p-6 rounded-2xl mt-2 backdrop-blur-md">
            <h3 className="text-[11px] font-black uppercase tracking-[0.3em] text-blue-400 mb-4">FOUNDATION LAYER: GOHIGHLEVEL INTEGRATION</h3>
            <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                <div className="space-y-1">
                    <span className="text-[9px] font-black text-white/40 uppercase tracking-widest block mb-2 underline decoration-blue-500/50 underline-offset-4">CRM & Automation Engine</span>
                    <div className="grid grid-cols-1 gap-1">
                        <Bullet text="Contact/Fan Database (Bi-directional Sync)" />
                        <Bullet text="Email & SMS Automation flows" />
                        <Bullet text="Workflows & Nurture Sequences" />
                        <Bullet text="Calendar & Appointments Engine" />
                    </div>
                </div>
                <div className="space-y-1">
                    <span className="text-[9px] font-black text-white/40 uppercase tracking-widest block mb-2 underline decoration-blue-500/50 underline-offset-4">Sync & Logic</span>
                    <div className="grid grid-cols-1 gap-1">
                        <Bullet text="Activity triggers GHL workflows" />
                        <Bullet text="Fan data syncs automatically via API" />
                        <Bullet text="Tags and custom fields stay in sync" />
                        <Bullet text="GHL handles high-volume comms" />
                    </div>
                </div>
            </div>
          </div>

          {/* Why Hybrid? Sticky Summary */}
          <div className="bg-white/5 border border-white/10 p-6 rounded-2xl mt-4 grid grid-cols-3 gap-6">
            <div className="text-center">
                <span className="text-lg font-black text-white block">BEST OF BOTH</span>
                <span className="text-[9px] font-bold text-white/40 uppercase leading-none">Custom UX + Proven Engine</span>
            </div>
            <div className="text-center border-x border-white/10">
                <span className="text-lg font-black text-emerald-400 block">$25K+ SAVED</span>
                <span className="text-[9px] font-bold text-white/40 uppercase leading-none">Leveraging existing infra</span>
            </div>
            <div className="text-center">
                <span className="text-lg font-black text-blue-400 block">FASTER MVP</span>
                <span className="text-[9px] font-bold text-white/40 uppercase leading-none">Launch ready from Day 1</span>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

const Bullet = ({ text, dark = false, dim = false }: { text: string; dark?: boolean; dim?: boolean }) => (
  <div className="flex items-center gap-2 group">
    <div className={`w-1 h-1 rounded-full ${dark ? 'bg-black/30' : dim ? 'bg-white/10' : 'bg-emerald-500'}`} />
    <span className={`text-[11px] font-bold leading-relaxed tracking-tight ${dark ? 'text-black/80' : dim ? 'text-white/30' : 'text-white/80'} group-hover:text-white transition-colors uppercase`}>
      {text}
    </span>
  </div>
);

export default HybridArchitectureSlide;
