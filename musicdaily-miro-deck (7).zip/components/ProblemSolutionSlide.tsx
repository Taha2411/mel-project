
import React from 'react';
import { Waveform } from '../constants';

const ProblemSolutionSlide: React.FC = () => {
  const comparisons = [
    { problem: "Scattered across 5+ platforms", solution: "One unified platform" },
    { problem: "High monthly costs ($100-300/mo)", solution: "Revenue share model" },
    { problem: "No fan data ownership", solution: "Artists own their data" },
    { problem: "Fragmented fan experience", solution: "Seamless hub experience" },
    { problem: "Manual payment tracking", solution: "Transparent auto-tracking" },
    { problem: "No cross-promotion", solution: "Built-in cross-pollination" },
    { problem: "Basic analytics only", solution: "Deep engagement metrics" },
    { problem: "No superfan monetization", solution: "Subscription + exclusivity" },
  ];

  return (
    <div className="relative w-full h-full flex flex-col p-12 text-white overflow-hidden bg-black/40 backdrop-blur-sm rounded-3xl border border-white/5 shadow-2xl">
      <Waveform />
      
      {/* Header */}
      <div className="w-full flex justify-between items-center mb-8 z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#FFB800] rounded flex items-center justify-center">
            <span className="text-black font-bold text-xs">04</span>
          </div>
          <h2 className="text-sm font-bold uppercase tracking-[0.3em] text-white/50">Problem → Solution</h2>
        </div>
        <div className="h-px flex-1 mx-8 bg-white/10" />
        <span className="text-xs font-mono text-[#FFB800]">MARKET_FIT_2026</span>
      </div>

      <div className="grid grid-cols-2 gap-8 z-10 flex-1 content-start">
        {/* Comparison Section */}
        <div className="bg-orange-500/5 border border-orange-500/20 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <span className="text-2xl">❌</span>
            <h3 className="text-lg font-black uppercase tracking-widest text-orange-400">Current State (Artist Pain)</h3>
          </div>
          <ul className="space-y-3">
            {comparisons.map((item, idx) => (
              <li key={idx} className="flex items-center gap-3 text-sm text-white/60">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500/40" />
                {item.problem}
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-[#FFB800]/5 border border-[#FFB800]/20 rounded-2xl p-6 shadow-[0_0_30px_rgba(255,184,0,0.05)]">
          <div className="flex items-center gap-3 mb-6">
            <span className="text-2xl">✅</span>
            <h3 className="text-lg font-black uppercase tracking-widest text-[#FFB800]">MusicDaily Solution</h3>
          </div>
          <ul className="space-y-3">
            {comparisons.map((item, idx) => (
              <li key={idx} className="flex items-center gap-3 text-sm font-bold text-white/90">
                <span className="w-1.5 h-1.5 rounded-full bg-[#FFB800]" />
                {item.solution}
              </li>
            ))}
          </ul>
        </div>

        {/* Opportunity Section */}
        <div className="col-span-2 grid grid-cols-3 gap-6 mt-4">
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 group hover:bg-white/[0.08] transition-all">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-white/10 rounded-lg text-white/60">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
              </div>
              <h4 className="text-xs font-black uppercase tracking-widest text-white/40">Market Size</h4>
            </div>
            <div className="flex items-baseline gap-2 mb-1">
              <span className="text-3xl font-black">100K+</span>
              <span className="text-[10px] font-bold text-white/40 uppercase">Emerging Artists</span>
            </div>
            <p className="text-[10px] leading-relaxed text-white/30">Average artist has 500-5k fans. 1-5% conversion to superfans = $50-500/mo recurring revenue potential.</p>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 group hover:bg-white/[0.08] transition-all">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-white/10 rounded-lg text-white/60">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              </div>
              <h4 className="text-xs font-black uppercase tracking-widest text-white/40">Revenue Model</h4>
            </div>
            <div className="flex items-center gap-4 mb-4">
              <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full bg-[#FFB800]" style={{ width: '80%' }} />
              </div>
              <span className="text-sm font-black">80/20</span>
            </div>
            <div className="flex justify-between text-[10px] font-bold uppercase tracking-tighter">
              <span className="text-[#FFB800]">80% Artist Share</span>
              <span className="text-white/40">20% MD Plat</span>
            </div>
          </div>

          <div className="bg-[#FFB800] border border-[#FFB800] rounded-2xl p-6 group shadow-[0_10px_30px_rgba(255,184,0,0.1)]">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-black/10 rounded-lg text-black/60">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
              </div>
              <h4 className="text-xs font-black uppercase tracking-widest text-black/40">Comp. Advantage</h4>
            </div>
            <h5 className="text-sm font-black text-black leading-tight uppercase mb-2">Full Stack Supremacy</h5>
            <p className="text-[10px] leading-relaxed text-black/60 font-medium">First-mover advantage in the emerging tier with an end-to-end unified solution. No more fragmentation.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProblemSolutionSlide;
