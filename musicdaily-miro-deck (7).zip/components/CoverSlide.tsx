
import React from 'react';
import { COLORS, Waveform, VinylIcon } from '../constants';

const CoverSlide: React.FC = () => {
  return (
    <div className="relative w-full h-full flex flex-col items-center justify-between p-16 text-white overflow-hidden bg-black/40 backdrop-blur-sm rounded-3xl border border-white/5 shadow-2xl">
      {/* Decorative Waveforms */}
      <Waveform />
      
      {/* Decorative Vinyls */}
      <VinylIcon className="absolute -top-20 -right-20 w-80 h-80 text-white/5" />
      <VinylIcon className="absolute -bottom-40 -left-40 w-96 h-96 text-white/5" />

      {/* Header Logo */}
      <div className="w-full flex justify-between items-start z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#FFB800] rounded-lg flex items-center justify-center">
            <svg className="w-6 h-6 text-black" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>
            </svg>
          </div>
          <span className="text-2xl font-black tracking-tighter uppercase">MusicDaily</span>
        </div>
        <div className="text-right">
          <p className="text-xs font-semibold uppercase tracking-widest text-white/40">Technical Presentation</p>
          <p className="text-xs font-semibold uppercase tracking-widest text-[#FFB800]">V1.0 - Confidential</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-col items-center text-center max-w-5xl z-10">
        <div className="w-24 h-1 bg-[#FFB800] mb-8 rounded-full" />
        <h1 className="text-6xl md:text-8xl font-extrabold tracking-tight mb-6 leading-none">
          MUSICDAILY <span className="text-[#FFB800]">PLATFORM</span>
        </h1>
        <h2 className="text-xl md:text-3xl font-light text-white/70 mb-12 uppercase tracking-[0.2em]">
          Technical Architecture & Implementation Strategy
        </h2>
        
        <div className="bg-white/5 px-8 py-4 rounded-full border border-white/10 mb-12">
          <p className="text-lg md:text-xl font-medium text-white/90">
            Multi-Artist Fan Engagement Platform for Emerging Artists
          </p>
        </div>
      </div>

      {/* Footer Info & Icons */}
      <div className="w-full flex flex-col md:flex-row items-end justify-between gap-8 z-10">
        <div className="flex flex-col gap-1 border-l-2 border-[#FFB800] pl-6 py-1">
          <div className="flex gap-2 text-sm text-white/50">
            <span>Prepared for:</span>
            <span className="text-white font-semibold">Mel Adler</span>
          </div>
          <div className="flex gap-2 text-sm text-white/50">
            <span>Date:</span>
            <span className="text-white font-semibold">January 2026</span>
          </div>
        </div>

        <div className="flex items-center gap-12 bg-black/60 px-10 py-6 rounded-2xl border border-white/10 backdrop-blur-md">
          <div className="flex flex-col items-center gap-2 group">
             <div className="w-12 h-12 flex items-center justify-center rounded-xl bg-[#FFB800]/10 text-[#FFB800] group-hover:bg-[#FFB800] group-hover:text-black transition-all">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" /></svg>
             </div>
             <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">Artists</span>
          </div>
          
          <div className="flex flex-col items-center gap-2 group">
             <div className="w-12 h-12 flex items-center justify-center rounded-xl bg-white/5 text-white/40 group-hover:bg-white group-hover:text-black transition-all">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
             </div>
             <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">Fans</span>
          </div>

          <div className="flex flex-col items-center gap-2 group">
             <div className="w-12 h-12 flex items-center justify-center rounded-xl bg-white/5 text-white/40 group-hover:bg-[#FFB800] group-hover:text-black transition-all">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.382-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" /></svg>
             </div>
             <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">Superfans</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CoverSlide;
