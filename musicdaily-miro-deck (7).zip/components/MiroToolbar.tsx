
import React from 'react';
import { COLORS } from '../constants';

const MiroToolbar: React.FC = () => {
  return (
    <div className="fixed left-6 top-1/2 -translate-y-1/2 bg-[#2A2A2A] rounded-xl shadow-2xl p-2 flex flex-col gap-4 border border-white/10 z-50">
      <ToolButton active>
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" /></svg>
      </ToolButton>
      <ToolButton>
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
      </ToolButton>
      <ToolButton>
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
      </ToolButton>
      <div className="h-px bg-white/10 mx-2" />
      <ToolButton>
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
      </ToolButton>
    </div>
  );
};

const ToolButton: React.FC<{ children: React.ReactNode; active?: boolean }> = ({ children, active }) => (
  <button className={`p-2.5 rounded-lg transition-all ${active ? 'bg-[#FFB800] text-black' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}>
    {children}
  </button>
);

export default MiroToolbar;
